import { db } from "./firebase-config.js";
import { 
    collection, 
    addDoc, 
    onSnapshot, 
    query, 
    orderBy, 
    doc, 
    updateDoc, 
    deleteDoc,
    setDoc
} from "https://www.gstatic.com/firebasejs/10.14.0/firebase-firestore.js";

// Elementos do DOM (Cardápio)
const form = document.getElementById("form-cadastro");
const tabelaLanches = document.getElementById("tabela-lanches");
const formTitulo = document.getElementById("form-titulo");
const btnSubmit = document.getElementById("btn-submit");
const idInput = document.getElementById("lanche-id");
const buscaNome = document.getElementById("busca-nome");
const filtroCategoria = document.getElementById("filtro-categoria");
const modalLanche = document.getElementById("modal-lanche");
const btnAbrirCadastro = document.getElementById("btn-abrir-cadastro");
const btnFecharModal = document.getElementById("btn-fechar-modal");

// Elementos do DOM (Pedidos em Tempo Real)
const listaPendentesContainer = document.getElementById("lista-pedidos-pendentes");
const listaAceitosContainer = document.getElementById("lista-pedidos-aceitos");
const somBuzina = document.getElementById("som-buzina");

let lanchesArmazenados = [];

// ==========================================\n// CONTROLADORES DO MODAL DE LANCHES\n// ==========================================
if (btnAbrirCadastro) {
    btnAbrirCadastro.addEventListener("click", () => {
        resetarFormulario();
        modalLanche.classList.remove("hidden");
    });
}
if (btnFecharModal) {
    btnFecharModal.addEventListener("click", () => {
        modalLanche.classList.add("hidden");
    });
}

// ==========================================\n// ESCUTA ATIVA DO CARDÁPIO (FIRESTORE)\n// ==========================================
const qCardapio = query(collection(db, "lanches"), orderBy("nome", "asc"));
onSnapshot(qCardapio, (snapshot) => {
    lanchesArmazenados = [];
    snapshot.forEach((doc) => {
        lanchesArmazenados.push({ id: doc.id, ...doc.data() });
    });
    filtrarEAplicarTabela();
});

if (buscaNome) buscaNome.addEventListener("input", filtrarEAplicarTabela);
if (filtroCategoria) filtroCategoria.addEventListener("change", filtrarEAplicarTabela);

function filtrarEAplicarTabela() {
    const termoBusca = buscaNome ? buscaNome.value.toLowerCase() : "";
    const catFiltro = filtroCategoria ? filtroCategoria.value : "todos";

    const filtrados = lanchesArmazenados.filter(lanche => {
        const correspondeNome = lanche.nome.toLowerCase().includes(termoBusca);
        const correspondeCat = catFiltro === "todos" || lanche.categoria === catFiltro;
        return correspondeNome && correspondeCat;
    });

    renderizarTabela(filtrados);
}

function renderizarTabela(itens) {
    if (!tabelaLanches) return;
    tabelaLanches.innerHTML = "";

    itens.forEach(lanche => {
        const tr = document.createElement("tr");
        tr.style.borderBottom = "1px solid #dee2e6";
        tr.innerHTML = `
            <td style="padding: 12px;"><img src="${lanche.imagemUrl}" style="width:50px; height:50px; object-fit:cover; border-radius:6px;" onerror="this.src='logo.jpg'"></td>
            <td style="padding: 12px; font-weight:600;">${lanche.nome}</td>
            <td style="padding: 12px; text-transform: capitalize;">${lanche.categoria}</td>
            <td style="padding: 12px; font-weight:600; color:var(--cor-primaria)">R$ ${parseFloat(lanche.preco).toFixed(2).replace('.', ',')}</td>
            <td style="padding: 12px; text-align:center;">
                <button class="btn-editar" data-id="${lanche.id}" style="background:#ffc107; border:none; padding:6px 12px; border-radius:6px; cursor:pointer; margin-right:5px; color:#212529;"><i class="fas fa-edit"></i></button>
                <button class="btn-excluir" data-id="${lanche.id}" style="background:#dc3545; border:none; padding:6px 12px; border-radius:6px; cursor:pointer; color:white;"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tabelaLanches.appendChild(tr);
    });

    configurarAcoesBotoes();
}

// ==========================================\n// CADASTRO / EDIÇÃO DE LANCHES (SUBMIT)\n// ==========================================
if (form) {
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const id = idInput.value;
        const dadosLanche = {
            nome: document.getElementById("nomeLanche").value,
            categoria: document.getElementById("categoria").value,
            preco: parseFloat(document.getElementById("preco").value),
            imagemUrl: document.getElementById("imagemUrl").value,
            descricao: document.getElementById("descricao").value
        };

        try {
            if (id) {
                await updateDoc(doc(db, "lanches", id), dadosLanche);
                alert("Lanche atualizado com sucesso!");
            } else {
                await addDoc(collection(db, "lanches"), dadosLanche);
                alert("Lanche incluído no cardápio!");
            }
            modalLanche.classList.add("hidden");
            resetarFormulario();
        } catch (error) {
            console.error("Erro ao salvar produto:", error);
            alert("Erro ao gravar produto no Firestore.");
        }
    });
}

function configurarAcoesBotoes() {
    document.querySelectorAll(".btn-editar").forEach(btn => {
        btn.addEventListener("click", (e) => {
            const id = e.currentTarget.getAttribute("data-id");
            const lanche = lanchesArmazenados.find(l => l.id === id);
            
            if (lanche) {
                idInput.value = lanche.id;
                document.getElementById("nomeLanche").value = lanche.nome;
                document.getElementById("categoria").value = lanche.categoria;
                document.getElementById("preco").value = lanche.preco;
                document.getElementById("imagemUrl").value = lanche.imagemUrl;
                document.getElementById("descricao").value = lanche.descricao;

                formTitulo.innerText = "Editar Lanche";
                btnSubmit.innerText = "Atualizar Cadastro";
                modalLanche.classList.remove("hidden");
            }
        });
    });

    document.querySelectorAll(".btn-excluir").forEach(btn => {
        btn.addEventListener("click", async (e) => {
            const id = e.currentTarget.getAttribute("data-id");
            const lanche = lanchesArmazenados.find(l => l.id === id);
            
            if (confirm(`Remover "${lanche.nome}" do cardápio definitivamente?`)) {
                try {
                    await deleteDoc(doc(db, "lanches", id));
                } catch (error) {
                    console.error("Erro ao deletar:", error);
                    alert("Não foi possível excluir o item.");
                }
            }
        });
    });
}

function resetarFormulario() {
    form.reset();
    idInput.value = "";
    formTitulo.innerText = "Novo Lanche";
    btnSubmit.innerText = "Salvar Produto";
}

// ==========================================================================\n// MONITORAMENTO DE PEDIDOS EM TEMPO REAL (ESTILO IFOOD)\n// ==========================================================================
const qPedidos = query(
    collection(db, "pedidos"),
    orderBy("data", "desc")
);

onSnapshot(qPedidos, (snapshot) => {
    let pendentesHtml = "";
    let aceitosHtml = "";
    let temPedidoPendente = false;
snapshot.forEach((docSnap) => {
    const pedido = {
        id: docSnap.id,
        ...docSnap.data()
    };
        
        let itensHtml = "";
        pedido.itens.forEach(item => {
            itensHtml += `<li>${item.quantidade}x ${item.nome}</li>`;
        });

        const cardHtml = `
            <div id="card-${pedido.id}" style="background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-left: 5px solid ${pedido.status === 'pendente' ? '#ff4d4f' : '#138342'}; margin-bottom: 5px;">
                <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 1rem; margin-bottom: 5px;">
                    <span>📦 ${pedido.id}</span>
                    <span style="color: #138342;">R$ ${parseFloat(pedido.total).toFixed(2).replace('.',',')}</span>
                </div>
                <div style="font-size: 0.85rem; color: #555; margin-bottom: 8px; line-height: 1.4;">
                    <strong>👤 ${pedido.cliente.nome}</strong> | 📞 ${pedido.cliente.telefone}<br>
                    📍 ${pedido.cliente.endereco.rua}, Nº ${pedido.cliente.endereco.numero} - ${pedido.cliente.endereco.bairro}<br>
                    💳 Pagamento: <strong>${pedido.cliente.formaPagamento}</strong> 
                    ${pedido.cliente.troco ? `(Troco: ${pedido.cliente.troco})` : ''}
                </div>
                <ul style="font-size: 0.9rem; padding-left: 20px; margin-bottom: 10px; color: #333;">
                    ${itensHtml}
                </ul>
                ${pedido.status === 'pendente' 
                    ? `<button onclick="aceitarEImprimir('${pedido.id}')" style="background: #ff4d4f; color: white; border: none; padding: 10px; border-radius: 6px; font-weight: bold; cursor: pointer; width: 100%; transition: 0.2s;"><i class="fas fa-print"></i> Aceitar e Imprimir</button>`
                    : `<span style="color: #138342; font-weight: bold; font-size: 0.85rem;"><i class="fas fa-check-circle"></i> Impresso &amp; Enviado para Cozinha</span>`
                }
            </div>
        `;

        if (pedido.status === "pendente") {
            pendentesHtml += cardHtml;
            temPedidoPendente = true;
        } else {
            aceitosHtml += cardHtml;
        }
    });

    if (listaPendentesContainer) {
        listaPendentesContainer.innerHTML = pendentesHtml || `<p style="color: #666; font-style: italic;">Nenhum pedido aguardando...</p>`;
        
        if (temPedidoPendente) {
            snapshot.forEach((docSnap) => {
                const pedido = docSnap.data();
                if (pedido.status === "pendente") {
                    const el = document.getElementById(`card-${pedido.id}`);
                    if (el) el.classList.add("pedido-alerta-ativo");
                }
            });
        }
    }
    
    if (listaAceitosContainer) {
        listaAceitosContainer.innerHTML = aceitosHtml || `<p style="color: #666; font-style: italic;">Nenhum pedido aceito hoje...</p>`;
    }

    // Controle do Buzinaço
    if (temPedidoPendente) {
        somBuzina.play().catch(err => {
            console.log("Aguardando interação com o painel administrativo para reproduzir áudio.");
        });
    } else {
        somBuzina.pause();
        somBuzina.currentTime = 0;
    }
});

// Ação Global disparada pelo botão "Aceitar e Imprimir"
window.aceitarEImprimir = async function(idPedido) {
    const elementoCard = document.getElementById(`card-${idPedido}`);
    if (!elementoCard) return;

    // Remove temporariamente o botão do HTML para não sair impresso no papel térmico
    const htmlClonado = elementoCard.cloneNode(true);
    const botaoImpressao = htmlClonado.querySelector("button");
    if (botaoImpressao) botaoImpressao.remove();

    const janelaImpressao = window.open('', '', 'height=600,width=450');
    janelaImpressao.document.write('<html><head><title>Imprimir Pedido</title>');
    janelaImpressao.document.write('<style>body { font-family: "Courier New", Courier, monospace; padding: 10px; color: black; } ul { padding-left: 20px; }</style></head><body>');
    janelaImpressao.document.write('<h2 style="text-align:center; margin-bottom:5px;">LANCHERIA COQUEIRO</h2>');
    janelaImpressao.document.write('<p style="text-align:center; margin-top:0;">---------------------------------</p>');
    janelaImpressao.document.write(htmlClonado.innerHTML);
    janelaImpressao.document.write('<p style="text-align:center; margin-top:15px;">---------------------------------</p>');
    janelaImpressao.document.write('<p style="text-align:center; font-size:11px;">Obrigado pela preferência!</p>');
    janelaImpressao.document.write('</body></html>');
    janelaImpressao.document.close();
    janelaImpressao.print();
    janelaImpressao.close();

    // Move o pedido da coluna "Aguardando" para a coluna "Pedidos Aceitos" no Firestore
    try {
        const pedidoRef = doc(db, "pedidos", idPedido);
        await updateDoc(pedidoRef, { status: "aceito" });
    } catch (error) {
        console.error("Erro ao transicionar status do pedido:", error);
    }
};

